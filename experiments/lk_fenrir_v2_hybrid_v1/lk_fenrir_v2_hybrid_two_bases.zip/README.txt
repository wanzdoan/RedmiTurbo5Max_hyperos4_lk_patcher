Two separate hybrid LK images: H3 stock/Fenrir base and H3 debug base.
Both: fake locked/green, AVB root-hash allowance, v2 public status, automatic HWC.
MTE policy preserved. Only one conditional post-load version maintenance call skipped.
No device flash, boot, root, OTA or Integrity confirmation for these new images.
Root descriptor probes are synthetic; full phone boot remains unverified.
Check SHA256SUMS.txt and per-image validation/manifest.
Full docs: experiments/lk_fenrir_v2_hybrid_v1/README_VI.md in the private repository.
