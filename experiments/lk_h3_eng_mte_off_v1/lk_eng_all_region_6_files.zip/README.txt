Six separate LK files: unlocked, fakelock v2, stock-policy; all use automatic HWC region.
Each directory has DEFAULT_POLICY (original filename) and MTE_OFF (filename suffix).
DEFAULT_POLICY does not force MTE on; it preserves the existing policy.
MTE_OFF forces the existing LK suppression path emitting arm64.nomte to the kernel.
It does not retroactively disable earlier preloader execution. No device boot test yet.
HWC routes cn to CN, other nonempty countrycodes to GLOBAL, missing/error to hardware HWC.
HWC mapping does not prove every ROM/signing key/rollback/model is compatible.
All files: 4043792 bytes. Check SHA256SUMS.txt before comparing files.
Full documentation: experiments/lk_h3_eng_mte_off_v1/README_VI.md in the private repository.
