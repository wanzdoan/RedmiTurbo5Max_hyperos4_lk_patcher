Original ENG stock policy + known China boot key; original ENG key retained.
No Global key added; no Global or automatic HWC patch.
Original HWC is CN on China hardware. No force unlock or fakelock.
DEFAULT preserves MTE policy; MTE_OFF requests kernel suppression via arm64.nomte.
Not device boot tested; root/relock/OTA/Integrity not established.
Full docs in experiments/lk_eng_stock_policy_cn_only_v1/README_VI.md.
