
undefined4 *
FUN_ffff0000b800aea8
          (undefined4 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
          undefined4 param_5,long param_6,undefined8 param_7)

{
  undefined8 uVar1;
  ulong uVar2;
  undefined8 *puVar3;
  undefined4 *puVar4;
  long lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  uint uVar8;
  
  if (param_1 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)FUN_ffff0000b804bccc(0x2d0);
    if (puVar4 == (undefined4 *)0x0) {
      return (undefined4 *)0x0;
    }
    uVar8 = 4;
  }
  else {
    uVar8 = 0;
    puVar4 = param_1;
  }
  FUN_ffff0000b804d070(puVar4,0,0x2d0);
  *puVar4 = 0x74687264;
  FUN_ffff0000b804d360(puVar4 + 0xac,param_2,0x20);
  *(undefined8 *)(puVar4 + 0x9e) = param_3;
  *(undefined8 *)(puVar4 + 0xa0) = param_4;
  puVar4[10] = param_5;
  puVar4[0xb] = 0;
  puVar4[0x12] = 0;
  puVar4[0xa2] = 0;
  puVar4[0xa4] = 0x77616974;
  *(undefined4 **)(puVar4 + 0xa6) = puVar4 + 0xa6;
  *(undefined4 **)(puVar4 + 0xa8) = puVar4 + 0xa6;
  puVar4[0xaa] = 0;
  *(undefined8 *)(puVar4 + 0xe) = 0;
  *(undefined8 *)(puVar4 + 0x10) = 0;
  if (param_6 == 0) {
    lVar5 = FUN_ffff0000b804bccc(param_7);
    *(long *)(puVar4 + 0x9a) = lVar5;
    if (lVar5 == 0) {
      if (param_1 != (undefined4 *)0x0) {
        return (undefined4 *)0x0;
      }
      thunk_FUN_ffff0000b8082558(puVar4);
      return (undefined4 *)0x0;
    }
    uVar8 = uVar8 | 2;
  }
  else {
    *(long *)(puVar4 + 0x9a) = param_6;
  }
  *(undefined8 *)(puVar4 + 0x9c) = param_7;
  puVar4[0xd] = uVar8;
  uVar1 = tpidr_el1;
  FUN_ffff0000b8007fd8(uVar1,puVar4);
  puVar7 = DAT_ffff0000b810ff38;
  uVar1 = daif;
  if (((uint)uVar1 >> 7 & 1) == 0) {
    uVar2 = daif;
    daif = uVar2 | 0x80;
    puVar6 = (undefined8 *)(puVar4 + 2);
    *puVar6 = &DAT_ffff0000b810ff30;
    puVar3 = puVar6;
    *(undefined8 **)(puVar4 + 4) = DAT_ffff0000b810ff38;
    DAT_ffff0000b810ff38 = puVar3;
    *puVar7 = puVar6;
    DAT_ffff0000b810ff28 = 0;
    uVar2 = daif;
    daif = uVar2 & 0xffffffffffffff7f;
  }
  else {
    DAT_ffff0000b810ff28 = 0;
    puVar7 = (undefined8 *)(puVar4 + 2);
    *puVar7 = &DAT_ffff0000b810ff30;
    *(undefined8 **)(puVar4 + 4) = DAT_ffff0000b810ff38;
    *DAT_ffff0000b810ff38 = puVar7;
    DAT_ffff0000b810ff38 = puVar7;
  }
  return puVar4;
}


